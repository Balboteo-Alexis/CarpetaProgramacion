package cd;

import cancion.Cancion;

public class CD {

	// Atributos de clase constantes
	public static final int NUM_MAX_CANCIONES = 20;

	// Atributos de clase variables

	// Atributos de objeto inmutables

	// Atributos de objeto variables
	private static Cancion[] canciones;
	private static int contador;

	// constructores

	public CD() {

		this.contador = 0;
		this.canciones = new Cancion[NUM_MAX_CANCIONES];

		for (int i = 0; i < NUM_MAX_CANCIONES; i++) {

			this.canciones[i] = null;

		}

	}

	public int numenoCanciones() {

		int num = 0;

		for (int i = 0; i < NUM_MAX_CANCIONES; i++) {

			if (this.canciones[i] != null) {
				num++;
			}

		}

		return num;
	}

	public Cancion dameCancion(int num) {

		Cancion seleccionada;

		seleccionada = this.canciones[num];

		return seleccionada;
	}

	public void grabaCancion(int num, Cancion nueva) {

		this.canciones[num] = nueva;

	}

	public void agrega(Cancion nueva) {

		this.canciones[contador] = nueva;
		this.contador++;
	}

	public void elimina(int num) {

		this.canciones[(num - 1)] = null;

	}

	public void copia(CD unCd) {

		for (int i = 0; i < NUM_MAX_CANCIONES; i++) {

			this.canciones[i] = unCd.canciones[i];

		}

		this.contador = unCd.contador;

	}

	public String toString() {

		String frase = "";

		for (int i = 0; i < NUM_MAX_CANCIONES; i++) {

			if (canciones[i] != null) {

				frase = frase + canciones[i].dameTitulo() + " ";

			}

		}

		return String.format("El CD tiene %d canciones y sus canciones son: %s", numenoCanciones(), frase);

	}

}
